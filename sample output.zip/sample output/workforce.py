"""
Python model ./test\workforce.py
Translated using PySD version 0.8.2-dev
"""
from __future__ import division
import numpy as np
from pysd import utils
import xarray as xr

from pysd.py_backend.functions import cache
from pysd.py_backend import functions

_subscript_dict = {}

_namespace = {
    'TIME':
    'time',
    'Time':
    'time',
    'Average Tenure':
    'average_tenure',
    'Departure':
    'departure',
    'Effect of Pressure on Hiring':
    'effect_of_pressure_on_hiring',
    'Expert Task Completion':
    'expert_task_completion',
    'Expert Time per Task':
    'expert_time_per_task',
    'Expert Workweek':
    'expert_workweek',
    '"Expert-Hours on Task per Week"':
    'experthours_on_task_per_week',
    '"Expert-Hours Spent on Rookie Supervision per Week"':
    'experthours_spent_on_rookie_supervision_per_week',
    '"Expert-Hours Worked per Week"':
    'experthours_worked_per_week',
    'Experts':
    'experts',
    'Hiring':
    'hiring',
    'Hours of Supervision Required per Rookie Per Week':
    'hours_of_supervision_required_per_rookie_per_week',
    'Maturation':
    'maturation',
    'Maturation Time':
    'maturation_time',
    'Pressure to Hire':
    'pressure_to_hire',
    'Rookie Task Completion':
    'rookie_task_completion',
    'Rookie Time per Task':
    'rookie_time_per_task',
    'Rookie Workweek':
    'rookie_workweek',
    '"Rookie-Hours on Task per Week"':
    'rookiehours_on_task_per_week',
    '"Rookie-Hours Worked per Week"':
    'rookiehours_worked_per_week',
    'Rookies':
    'rookies',
    'Target Backlog':
    'target_backlog',
    'Task Arrival':
    'task_arrival',
    'Task Backlog':
    'task_backlog',
    'Task Completion':
    'task_completion',
    'FINAL TIME':
    'final_time',
    'INITIAL TIME':
    'initial_time',
    'SAVEPER':
    'saveper',
    'TIME STEP':
    'time_step',
    'init Experts':
    'init_experts',
    'init Rookies':
    'init_rookies',
    'init Task Backlog':
    'init_task_backlog'
}


@cache('run')
def average_tenure():
    """
    Average Tenure

    [30,300,1]

    constant


    """
    return 35


@cache('step')
def departure():
    """
    Departure

    Persons/Week

    component


    """
    return experts() / average_tenure()


def effect_of_pressure_on_hiring(x):
    """
    Effect of Pressure on Hiring



    lookup


    """
    return functions.lookup(x, [-1, -0.25, 0, 0.5, 1, 2, 3], [0, 0, 2.5, 15, 20, 25, 25])


@cache('step')
def expert_task_completion():
    """
    Expert Task Completion

    Tasks/Week

    component


    """
    return experthours_on_task_per_week() / expert_time_per_task()


@cache('run')
def expert_time_per_task():
    """
    Expert Time per Task

    Person*Hours

    constant


    """
    return 10


@cache('run')
def expert_workweek():
    """
    Expert Workweek

    Hours/Week

    constant


    """
    return 40


@cache('step')
def experthours_on_task_per_week():
    """
    "Expert-Hours on Task per Week"

    Person*Hours/Week

    component


    """
    return experthours_worked_per_week() - experthours_spent_on_rookie_supervision_per_week()


@cache('step')
def experthours_spent_on_rookie_supervision_per_week():
    """
    "Expert-Hours Spent on Rookie Supervision per Week"

    Hours*Person/Week

    component


    """
    return hours_of_supervision_required_per_rookie_per_week() * rookies()


@cache('step')
def experthours_worked_per_week():
    """
    "Expert-Hours Worked per Week"

    Hours*Person/Week

    component


    """
    return experts() * expert_workweek()


@cache('step')
def experts():
    """
    Experts



    component


    """
    return integ_experts()


@cache('step')
def hiring():
    """
    Hiring

    Persons/Week

    component


    """
    return effect_of_pressure_on_hiring(pressure_to_hire())


@cache('run')
def hours_of_supervision_required_per_rookie_per_week():
    """
    Hours of Supervision Required per Rookie Per Week

    Person*Hours/Person

    constant


    """
    return 20


@cache('step')
def maturation():
    """
    Maturation

    Persons/Week

    component


    """
    return rookies() / maturation_time()


@cache('run')
def maturation_time():
    """
    Maturation Time

    Weeks [0,80]

    constant


    """
    return 15


@cache('step')
def pressure_to_hire():
    """
    Pressure to Hire



    component


    """
    return (task_backlog() - target_backlog()) / target_backlog()


@cache('step')
def rookie_task_completion():
    """
    Rookie Task Completion

    Tasks/Week

    component


    """
    return rookiehours_on_task_per_week() / rookie_time_per_task()


@cache('run')
def rookie_time_per_task():
    """
    Rookie Time per Task

    Person*Hours

    constant


    """
    return 30


@cache('run')
def rookie_workweek():
    """
    Rookie Workweek

    Hours/Week

    constant


    """
    return 40


@cache('step')
def rookiehours_on_task_per_week():
    """
    "Rookie-Hours on Task per Week"

    Person*Hours/Week

    component


    """
    return rookiehours_worked_per_week()


@cache('step')
def rookiehours_worked_per_week():
    """
    "Rookie-Hours Worked per Week"

    Person Hours

    component


    """
    return rookie_workweek() * rookies()


@cache('step')
def rookies():
    """
    Rookies



    component


    """
    return integ_rookies()


@cache('run')
def target_backlog():
    """
    Target Backlog



    constant


    """
    return 500


@cache('run')
def task_arrival():
    """
    Task Arrival

    Tasks/Week

    constant


    """
    return 230


@cache('step')
def task_backlog():
    """
    Task Backlog

    Tasks

    component


    """
    return integ_task_backlog()


@cache('step')
def task_completion():
    """
    Task Completion



    component


    """
    return np.minimum(expert_task_completion() + rookie_task_completion(), task_backlog())


@cache('run')
def final_time():
    """
    FINAL TIME

    Week

    constant

    The final time for the simulation.
    """
    return 150


@cache('run')
def initial_time():
    """
    INITIAL TIME

    Week

    constant

    The initial time for the simulation.
    """
    return 0


@cache('step')
def saveper():
    """
    SAVEPER

    Week [0,?]

    component

    The frequency with which output is stored.
    """
    return time_step()


@cache('run')
def time_step():
    """
    TIME STEP

    Week [0,?]

    constant

    The time step for the simulation.
    """
    return 0.03125


@cache('run')
def init_experts():
    """
    init Experts



    constant

    initial value for Experts
    """
    return 50


@cache('run')
def init_rookies():
    """
    init Rookies



    constant

    initial value for Rookies
    """
    return 5


@cache('run')
def init_task_backlog():
    """
    init Task Backlog

    Tasks

    constant

    initial value for Task Backlog
    """
    return 500


integ_experts = functions.Integ(lambda: maturation() - departure(), lambda: init_experts())

integ_rookies = functions.Integ(lambda: hiring() - maturation(), lambda: init_rookies())

integ_task_backlog = functions.Integ(lambda: task_arrival() - task_completion(),
                                     lambda: init_task_backlog())
